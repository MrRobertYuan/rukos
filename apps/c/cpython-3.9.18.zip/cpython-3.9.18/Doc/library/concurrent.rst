The :mod:`concurrent` package
=============================

Currently, there is only one module in this package:

* :mod:`concurrent.futures` -- Launching parallel tasks
